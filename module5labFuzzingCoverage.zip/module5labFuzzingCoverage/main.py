import inspect  # for getsource
import matplotlib.pyplot as plt
from coverage import Coverage, fuzzer, population_coverage, generate_inputs
from testfunctions import pause 

################################################
# Task 1 
# Use assert statements to test 3 scores according to the specifications
from testfunctions import rank_scores

# Test score 100000
assert rank_scores(100000) == 10, "Score 100000 should have rank 10"

# Test score 90000
assert rank_scores(90000) == 9, "Score 90000 should have rank 9"

# Test score 75000
assert rank_scores(75000) == 8, "Score 75000 should have rank 8"

# Add more assert statements to test additional scores

print("All assertions passed.")

pause()

################################################
# Task 2
import inspect
from testfunctions import rank_scores

# Get the source code of the rank_scores function
source_code = inspect.getsource(rank_scores)

# Split the source code into individual lines
lines = source_code.splitlines()

# Print all the lines of the code
for line in lines:
    print(line)

pause()
################################################

# Task 3
# Use the Coverage class once to test all specified ranks (include a try/except block for an invalid integer value) (Similar to cov_max in example code) Print the coverage result.
from coverage import Coverage
from testfunctions import rank_scores

cov = Coverage()

try:
    cov.start()

    # Test rank 10
    rank_scores(100000)

    # Test rank 9
    rank_scores(90000)

    # Test rank 8
    rank_scores(75000)

    # Test rank 7
    rank_scores(50000)

    # Test rank 6
    rank_scores(25000)

    # Test rank 5
    rank_scores(10000)

    # Test rank 4
    rank_scores(5000)

    # Test rank 3
    rank_scores(1000)

    # Test rank 2
    rank_scores(500)

    # Test rank 1
    rank_scores(1)

    # Test rank 0
    rank_scores(0)

    # Test rank -1
    rank_scores(-100)

except ValueError:
    print("Invalid score value")

cov.stop()
cov.report()


pause() 
################################################
# Task 4 Test with single fuzz input. Customize the provided fuzz function to use numeric characters up to 7 characters long

# Use the Coverage class and test the function with that sample fuzz input. Print the coverage result. 

# Find the difference between the max coverage found in task 3 and this fuzz coverage. Print the difference results.

import random
import string
from coverage import Coverage
from testfunctions import rank_scores

def fuzz():
    # Generate a fuzz input with numeric characters up to 7 characters long
    return ''.join(random.choice(string.digits) for _ in range(1, 8))

cov = Coverage()

try:
    cov.start()

    # Get a fuzz input
    fuzz_input = fuzz()

    # Test the function with the fuzz input
    rank_scores(fuzz_input)

except ValueError:
    print("Invalid score value")

cov.stop()
cov_max = Coverage()
cov_max.start()
rank_scores(100000)
rank_scores(90000)
rank_scores(75000)
cov_max.stop()
max_coverage = cov_max.report()
fuzz_coverage = cov.report()
difference = max_coverage - fuzz_coverage

print("Difference in coverage:", difference)

################################################
# Task 5 Set up an experiment with 200 fuzz inputs and plot the results. Save the plot results to a png image.
import matplotlib.pyplot as plt
from coverage import Coverage, fuzzer, population_coverage

# Create an instance of the Coverage class
cov = Coverage()

# Generate 200 fuzz inputs
fuzz_inputs = [fuzzer() for _ in range(200)]

# Test the rank_scores function with the fuzz inputs
cov.start()
for fuzz_input in fuzz_inputs:
    rank_scores(fuzz_input)
cov.stop()

# Calculate the coverage
cov_result = cov.get_coverage()

# Plot the coverage result
plt.plot(cov_result)
plt.xlabel('Test Case')
plt.ylabel('Coverage')
plt.title('Coverage of rank_scores Function')
plt.savefig('coverage_plot.png')
plt.show()

pause()

################################################
# Task 6 Repeat the previous experiment, but run it 500 times (This may take a little while to complete running). Find the average coverage and plot the results. Save the plot to a different png image.
import matplotlib.pyplot as plt
from coverage import Coverage, fuzzer, population_coverage

# Create an instance of the Coverage class
cov = Coverage()

# Variables to store coverage results
coverage_results = []
total_coverage = 0

# Repeat the experiment 500 times
for _ in range(500):
    # Generate fuzz input
    fuzz_input = fuzzer()
    
    # Test the rank_scores function with the fuzz input
    cov.start()
    rank_scores(fuzz_input)
    cov.stop()
    
    # Calculate and store the coverage for the current test case
    cov_result = cov.get_coverage()
    coverage_results.append(cov_result[0])  # Store the coverage of the first line
    total_coverage += cov_result[0]  # Accumulate the coverage
    
# Calculate the average coverage
average_coverage = total_coverage / 500

# Plot the coverage results
plt.plot(coverage_results)
plt.xlabel('Experiment')
plt.ylabel('Coverage')
plt.title('Coverage of rank_scores Function (500 experiments)')
plt.savefig('coverage_plot_500.png')
plt.show()

print("Average Coverage:", average_coverage)

pause()
################################################