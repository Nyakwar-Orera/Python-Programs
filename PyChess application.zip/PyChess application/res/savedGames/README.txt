This is a folder where all games are stored.
If you use savegame feature, the file gets saved here with a gameid.
Load it using the loadgame feature in main menu.