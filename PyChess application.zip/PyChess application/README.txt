Install pygame (at cmd run :  pip install pygame)
install chess (at cmd run: pip install chess) 


run main.py