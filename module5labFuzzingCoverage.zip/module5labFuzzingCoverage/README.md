# Module 5 Lab - Fuzzing Coverage
Please use the code here: 
https://replit.com/@jholst/FuzzingCoverage  
as a guide for this lab.  

Instead of testing cgi_decode, this lab will test the rank_scores function defined in the testfunctions.py file in this replit. The specifications for the function can be seen along with the actual implementation. 

(You do not need to change anything in coverage.py or testfunctions.py.)

## Task 1 
- Use assert statements to test 3 scores according to the specifications

## Task 2
- Use the getsource function in the inspect module to retrieve the source code of the function 

- break the code into a list of individual lines 

- print all the lines of the code

## Task 3
- Use the Coverage class once to test all specified ranks (include a try/except block for an invalid integer value) (Similar to cov_max in example code) Print the coverage result.

## Task 4 
- Test with single fuzz input. Customize the provided fuzz function to use numeric characters up to 7 characters long

- Use the Coverage class and test the function with that sample fuzz input. Print the coverage result. 

- Find the difference between the max coverage found in task 3 and this fuzz coverage. Print the difference results.
      
## Task 5 
- Set up an experiment with 200 fuzz inputs and plot the results. Save the plot results to a png image.

## Task 6 
- Repeat the previous experiment, but run it 500 times (This may take a little while to complete running). Find the average coverage and plot the results. Save the plot to a different png image.